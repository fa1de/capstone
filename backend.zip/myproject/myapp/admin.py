from django.contrib import admin
from .models import ProtocolInfo


# Register your models here.
admin.site.register(ProtocolInfo)
